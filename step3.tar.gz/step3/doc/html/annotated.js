var annotated =
[
    [ "Elf_Arhdr", "struct_elf___arhdr.html", "struct_elf___arhdr" ],
    [ "Elf_Arsym", "struct_elf___arsym.html", "struct_elf___arsym" ],
    [ "Elf_Data", "struct_elf___data.html", "struct_elf___data" ],
    [ "MemZone", "struct_mem_zone.html", "struct_mem_zone" ],
    [ "mips", "structmips.html", "structmips" ],
    [ "nodeSymbol", "structnode_symbol.html", "structnode_symbol" ],
    [ "registre", "structregistre.html", "structregistre" ],
    [ "SectionELF", "struct_section_e_l_f.html", "struct_section_e_l_f" ]
];