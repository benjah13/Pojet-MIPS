var constantes_8h =
[
    [ "CMD_EMPTY_RETURN_VALUE", "constantes_8h.html#a4e38b03e7c9b1deafea6828576f90c6f", null ],
    [ "CMD_EXIT_RETURN_VALUE", "constantes_8h.html#ab7ef3dc73bd9c4f7a5bff57c3a02625e", null ],
    [ "CMD_OK_RETURN_VALUE", "constantes_8h.html#a83be1ec9436290cec1a78529190ee4da", null ],
    [ "CMD_UNKOWN_RETURN_VALUE", "constantes_8h.html#ae885796f2f2e6bfa2ef9b6d0a73a2b9d", null ],
    [ "MAX_STR", "constantes_8h.html#a8b6d77865140befe3a9bc16132d2e696", null ],
    [ "PROMPT_STRING", "constantes_8h.html#a0952d8419613015b8951edaf152606f4", null ]
];