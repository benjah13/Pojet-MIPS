var global_8h =
[
    [ "TAILLEMEM", "global_8h.html#afa25ad972e09b6001b2ec85cbd264ed8", null ],
    [ "TAILLESEGMENT", "global_8h.html#afc9973e66c831c97f8dcc7f4dde47993", null ],
    [ "BYTE", "global_8h.html#a4ae1dab0fb4b072a66584546209e7d58", null ],
    [ "WORD", "global_8h.html#ad2baa11c897721ff6f14b452b547f9bc", null ]
];