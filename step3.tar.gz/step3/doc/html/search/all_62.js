var searchData=
[
  ['bss',['BSS',['../structure_8h.html#a476baf4669c951eb7864d94f15a49f75',1,'structure.h']]],
  ['byte',['BYTE',['../global_8h.html#a4ae1dab0fb4b072a66584546209e7d58',1,'global.h']]]
];
