var searchData=
[
  ['warning_5fmsg',['WARNING_MSG',['../notify_8h.html#ab45f4dc5f3514effe22ad6bc392f25f0',1,'notify.h']]],
  ['word',['WORD',['../global_8h.html#ad2baa11c897721ff6f14b452b547f9bc',1,'global.h']]]
];
