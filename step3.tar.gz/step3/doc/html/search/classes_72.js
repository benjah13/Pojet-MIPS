var searchData=
[
  ['registre',['registre',['../structregistre.html',1,'']]]
];
