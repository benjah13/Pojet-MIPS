var searchData=
[
  ['bss',['BSS',['../structure_8h.html#a476baf4669c951eb7864d94f15a49f75',1,'structure.h']]]
];
