var searchData=
[
  ['data',['DATA',['../structure_8h.html#aad9ae913bdfab20dd94ad04ee2d5b045',1,'structure.h']]],
  ['debug_5fmsg',['DEBUG_MSG',['../notify_8h.html#ae0188c06a0b9870c90e05292f629c1d1',1,'notify.h']]]
];
