var searchData=
[
  ['for_5ferrors',['FOR_ERRORS',['../notify_8h.html#aadeeb4dafe17c7a9e1a99f21c61a77e2',1,'notify.h']]],
  ['for_5finfos',['FOR_INFOS',['../notify_8h.html#a189e6cf5e841495c54fac2a0c527e7a9',1,'notify.h']]],
  ['for_5fwarnings',['FOR_WARNINGS',['../notify_8h.html#a73e9f0c4c8ec0c165519779de7a7bec7',1,'notify.h']]]
];
