var searchData=
[
  ['numzone',['NUMZONE',['../mipself_8h.html#a75aab9ccd6ddc758207a7d5dc6589174',1,'mipself.h']]]
];
