var searchData=
[
  ['set_5fcolors',['SET_COLORS',['../notify_8h.html#a511f2e52b44bfddb2a467a1a19851662',1,'notify.h']]],
  ['style',['STYLE',['../notify_8h.html#ad03e9c909b32d5020e6213af09622a5c',1,'notify.h']]],
  ['style_5fblink',['STYLE_BLINK',['../notify_8h.html#a003d730c9ff7f83ca05b1aa28fa44fdd',1,'notify.h']]],
  ['style_5fbold',['STYLE_BOLD',['../notify_8h.html#a7ce3d6fee94f21c9e3d0ffdd90aadc2e',1,'notify.h']]],
  ['style_5fconcealed',['STYLE_CONCEALED',['../notify_8h.html#a6f729201849854f38b1711b91c63cff5',1,'notify.h']]],
  ['style_5ferror',['STYLE_ERROR',['../notify_8h.html#a011bb291a0f03af56da9c5fff3fcacf9',1,'notify.h']]],
  ['style_5finfo',['STYLE_INFO',['../notify_8h.html#ae3a086385379ed8e9c4fb21181b36385',1,'notify.h']]],
  ['style_5foff',['STYLE_OFF',['../notify_8h.html#ad6baacc6caa0191e810735b01e81aec3',1,'notify.h']]],
  ['style_5freverse',['STYLE_REVERSE',['../notify_8h.html#a6f8e52655d37a72b5469ce655c4cb6f1',1,'notify.h']]],
  ['style_5fuscore',['STYLE_USCORE',['../notify_8h.html#ac5a7435261840035b1a6919dc7207be9',1,'notify.h']]],
  ['style_5fwarning',['STYLE_WARNING',['../notify_8h.html#a7422478a5ea88e3e80c74fda52fd9711',1,'notify.h']]]
];
