var searchData=
[
  ['taillemem',['TAILLEMEM',['../global_8h.html#afa25ad972e09b6001b2ec85cbd264ed8',1,'global.h']]],
  ['taillesegment',['TAILLESEGMENT',['../global_8h.html#afc9973e66c831c97f8dcc7f4dde47993',1,'global.h']]],
  ['text',['TEXT',['../structure_8h.html#a52e3db5a1724beab41ebbabe72460f12',1,'structure.h']]]
];
