var searchData=
[
  ['init_5fmips',['init_mips',['../fonctions_step1_8c.html#ab0df037e9b8b8fc6fe0f4bec6491d8f7',1,'init_mips(mips *arch):&#160;fonctionsStep1.c'],['../fonctions_step1_8h.html#ab0df037e9b8b8fc6fe0f4bec6491d8f7',1,'init_mips(mips *arch):&#160;fonctionsStep1.c']]],
  ['init_5fsegment',['init_segment',['../fonctions_step1_8c.html#ad1426d9efcda7f8040f9bf2c8e22f784',1,'init_segment(SectionELF *seg, int type):&#160;fonctionsStep1.c'],['../fonctions_step1_8h.html#ad1426d9efcda7f8040f9bf2c8e22f784',1,'init_segment(SectionELF *seg, int type):&#160;fonctionsStep1.c']]]
];
