var searchData=
[
  ['shtname',['shtName',['../mipself_8c.html#a8540557372dc0c502abb143cc0625ff5',1,'shtName(Elf32_Word SectionType):&#160;mipself.c'],['../mipself_8h.html#a8540557372dc0c502abb143cc0625ff5',1,'shtName(Elf32_Word SectionType):&#160;mipself.c']]],
  ['stname',['stName',['../mipself_8c.html#aeda1162e1720814486dfd8eb2498ba9f',1,'stName(unsigned char t):&#160;mipself.c'],['../mipself_8h.html#aeda1162e1720814486dfd8eb2498ba9f',1,'stName(unsigned char t):&#160;mipself.c']]]
];
