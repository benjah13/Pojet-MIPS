var searchData=
[
  ['test_5fmemoire',['test_memoire',['../tests_step1_8c.html#afe9911c3e6467e08f3f68c39bbdbf378',1,'test_memoire(mips *arch, unsigned int adresse, unsigned int *addr_in_block):&#160;testsStep1.c'],['../tests_step1_8h.html#afe9911c3e6467e08f3f68c39bbdbf378',1,'test_memoire(mips *arch, unsigned int adresse, unsigned int *addr_in_block):&#160;testsStep1.c']]],
  ['test_5fregistre',['test_registre',['../tests_step1_8c.html#a278516fb1d8f015a7618e34d97bf1565',1,'test_registre(char *input):&#160;testsStep1.c'],['../tests_step1_8h.html#a278516fb1d8f015a7618e34d97bf1565',1,'test_registre(char *input):&#160;testsStep1.c']]],
  ['test_5fvaleur',['test_valeur',['../tests_step1_8c.html#a7a9eb0c20a07255d9268e52099cf0e3d',1,'test_valeur(unsigned int val):&#160;testsStep1.c'],['../tests_step1_8h.html#a7a9eb0c20a07255d9268e52099cf0e3d',1,'test_valeur(unsigned int val):&#160;testsStep1.c']]]
];
