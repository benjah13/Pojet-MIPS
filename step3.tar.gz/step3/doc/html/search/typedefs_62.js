var searchData=
[
  ['byte',['BYTE',['../global_8h.html#a4ae1dab0fb4b072a66584546209e7d58',1,'global.h']]]
];
