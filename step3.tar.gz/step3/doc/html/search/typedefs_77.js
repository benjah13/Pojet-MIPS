var searchData=
[
  ['word',['WORD',['../global_8h.html#ad2baa11c897721ff6f14b452b547f9bc',1,'global.h']]]
];
