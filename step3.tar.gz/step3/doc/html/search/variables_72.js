var searchData=
[
  ['reg',['reg',['../structmips.html#a850f3c5ce0558bc004d3bafaffd48e02',1,'mips']]],
  ['rel_5fname',['rel_name',['../struct_mem_zone.html#a3620bf59a872d1f7c7ff4f372a5dcc91',1,'MemZone']]],
  ['rel_5fscn',['rel_scn',['../struct_mem_zone.html#a791a8b1cd288f7aed2dc3cdd77e54e52',1,'MemZone']]]
];
