var struct_elf___arhdr =
[
    [ "ar_date", "struct_elf___arhdr.html#afdcdfb007d3663a647e573fcd7476148", null ],
    [ "ar_gid", "struct_elf___arhdr.html#a33bea9112c0482b24dc067b370ba2d51", null ],
    [ "ar_mode", "struct_elf___arhdr.html#ab1fb4a3f6d72dc9966ec7045ecefaa9c", null ],
    [ "ar_name", "struct_elf___arhdr.html#a6f32a7e7c8bd64df5c2b1fd10f758ccb", null ],
    [ "ar_rawname", "struct_elf___arhdr.html#ac6c218297c1c96f8efcf1809635bc1c6", null ],
    [ "ar_size", "struct_elf___arhdr.html#a604bd99d46718a74378e0b1a5690faf4", null ],
    [ "ar_uid", "struct_elf___arhdr.html#a70452a4221037e637533f4f208bd9122", null ]
];