var struct_elf___data =
[
    [ "d_align", "struct_elf___data.html#a5416f794178e8e752bc27b3e2751827e", null ],
    [ "d_buf", "struct_elf___data.html#a1359b01d51e81c439649e50e0228dbd7", null ],
    [ "d_off", "struct_elf___data.html#a76ed4b4aeb474d605e84a4320f054248", null ],
    [ "d_size", "struct_elf___data.html#a30bc3455be56d05848d0a0f737d72cf5", null ],
    [ "d_type", "struct_elf___data.html#a376952c5e9c01e467788dcfc62216771", null ],
    [ "d_version", "struct_elf___data.html#a39da3806e0e01d780fd0d28a05e36038", null ]
];