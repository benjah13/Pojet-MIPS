var struct_mem_zone =
[
    [ "data", "struct_mem_zone.html#ac24cea2bfcc927fd29bc74d1086707d8", null ],
    [ "exportSection", "struct_mem_zone.html#a989932f35bc189b0b859b9293fde129c", null ],
    [ "index", "struct_mem_zone.html#a129a0ce32a1aa17dafbf00cfecfb2a9c", null ],
    [ "mem_start", "struct_mem_zone.html#a22217808f0c5242a891133c1a57472f8", null ],
    [ "name", "struct_mem_zone.html#a5ac083a645d964373f022d03df4849c8", null ],
    [ "rel_name", "struct_mem_zone.html#a3620bf59a872d1f7c7ff4f372a5dcc91", null ],
    [ "rel_scn", "struct_mem_zone.html#a791a8b1cd288f7aed2dc3cdd77e54e52", null ],
    [ "scn", "struct_mem_zone.html#a55c4ddbe81d8195c776ab5eb43d4b430", null ],
    [ "size", "struct_mem_zone.html#a6cdb7ee15e451582ee7eb23fea2939a1", null ],
    [ "type", "struct_mem_zone.html#ac88b495652795d7e786ae9c807df8470", null ]
];