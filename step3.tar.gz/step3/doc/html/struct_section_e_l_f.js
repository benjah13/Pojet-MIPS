var struct_section_e_l_f =
[
    [ "data", "struct_section_e_l_f.html#a3d1ef01c0aa6dd4984364db3f2d26fd2", null ],
    [ "name", "struct_section_e_l_f.html#a5ac083a645d964373f022d03df4849c8", null ],
    [ "size", "struct_section_e_l_f.html#ab5f22e98966d6ff77cfdb00b2c6f63c1", null ],
    [ "startAddress", "struct_section_e_l_f.html#aeae59a8aaab82dc460026cb669bdf3fc", null ]
];