var structmips =
[
    [ "reg", "structmips.html#a850f3c5ce0558bc004d3bafaffd48e02", null ],
    [ "segment", "structmips.html#ac97d3180762159eaebcc9b03ecba57c3", null ]
];