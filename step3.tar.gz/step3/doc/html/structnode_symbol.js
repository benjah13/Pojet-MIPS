var structnode_symbol =
[
    [ "adr", "structnode_symbol.html#a8f4c3bb1e709a9fbfea922a956fc5cd1", null ],
    [ "name", "structnode_symbol.html#a5ac083a645d964373f022d03df4849c8", null ],
    [ "suiv", "structnode_symbol.html#a87372660f96867008855af85c4057b7c", null ]
];