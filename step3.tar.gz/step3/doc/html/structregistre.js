var structregistre =
[
    [ "indice", "structregistre.html#a3d17db3506a2322e40f591f2d1414c05", null ],
    [ "mnemo", "structregistre.html#a124151291ba6f58b7dfa62b9bcc6bd52", null ],
    [ "val", "structregistre.html#a9163138d612480a614fa98c44e4318c4", null ]
];