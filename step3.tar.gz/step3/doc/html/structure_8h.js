var structure_8h =
[
    [ "BSS", "structure_8h.html#a476baf4669c951eb7864d94f15a49f75", null ],
    [ "DATA", "structure_8h.html#aad9ae913bdfab20dd94ad04ee2d5b045", null ],
    [ "TEXT", "structure_8h.html#a52e3db5a1724beab41ebbabe72460f12", null ]
];