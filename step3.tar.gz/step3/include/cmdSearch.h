#ifndef __CMDSEARCH_H__
#define __CMDSEARCH_H__

char* cmdSearch(char* type, unsigned int param);

#endif