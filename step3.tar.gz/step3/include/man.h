#ifndef __MAN_H__
#define __MAN_H__

int man(void);


#endif